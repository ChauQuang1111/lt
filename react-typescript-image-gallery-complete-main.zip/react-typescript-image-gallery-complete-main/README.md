# react-typescript-image-gallery
![react-typescript-image-gallery](/src/assets//github-cover.png)

# How to use
Some basic commands are:
```
npm install
npm run dev
```
1. clone this repository or just download the starter files from here
1. unzip or extract the downloaded files
1. use `cd folder-name' to go to the root folder inside
1. command `npm install` first, then `npm run dev`  to open this project on web browser