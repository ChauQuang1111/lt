export interface IImageGallery {
  id: number | string;
  slug: string;
  isSelected: boolean;
}
