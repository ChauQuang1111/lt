package com.aldrin.foodfam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodfamApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
