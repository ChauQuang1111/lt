/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aldrin.sms.entity;

/**
 *
 * @author ALDRIN B. C.
 */

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
